﻿package com.example.diarycustom

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


class DiarywriteFragment : Fragment() {

    // 안되면 여기 두 줄 지우기
    lateinit var adapter: NoteAdapter
    lateinit var recyclerView: RecyclerView

    var mMode = AppConstants.MODE_INSERT
    var item: Note? = null
    var listener: OnTabItemSelectedListener? = null
    var dateTextView: TextView? = null
    var locationTextView: TextView? = null
    var contentsInput: EditText? = null
    var pictureImageView: ImageView? = null
    var resultPhotoBitmap: Bitmap? = null
    var todayDateFormat: SimpleDateFormat? = null
    var currentDateString: String? = null

//    var isPhotoCaptured = false
//    var isPhotoFileSaved = false
//    var isPhotoCanceled = false
//    var selectedPhotoMenu = 0
//    var uri: Uri? = null
//    var file: File? = null

    lateinit var rootView: View

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnTabItemSelectedListener) {
            listener = context
        } else {
            Log.d("TEST", "Not OnTabItemSelectedListener.") //안되면지우깅깅
       }
    }

    override fun onDetach() {
        super.onDetach()
        if (context != null) {
            listener = null
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
      //  val rootView: View = inflater.inflate(R.layout.fragment_diarywrite, container, false) as ViewGroup

        //initUI(rootView) //안되면 rootView 삭제
//        applyItem()
//        return rootView
        return inflater.inflate(R.layout.fragment_diarywrite, container, false)
    }

    fun initUI(rootView: View) {
        val WriteButton = rootView.findViewById<Button>(R.id.WriteButton)
        WriteButton.setOnClickListener {
            listener?.onTabSelected(1)
        }
        dateTextView = rootView.findViewById(R.id.dateTextView)
        locationTextView = rootView.findViewById(R.id.locationTextView)
        contentsInput = rootView.findViewById(R.id.contentsInput)
        pictureImageView = rootView.findViewById(R.id.pictureImageView)
    }

    // 해보고 안되면 지우기
    fun applyItem() {
        if (item != null) {
            mMode = AppConstants.MODE_MODIFY
            assignAddress(item!!.address)
            assignDateString(item!!.createDateStr)
            assignContents(item!!.contents)
            val picturePath: String = item!!.picture
            if (picturePath == null || picturePath == "") {
                pictureImageView!!.setImageResource((R.drawable.noimagefound))
            } else {
                assignPicture(item!!.picture, 1)
            }
        } else {
            mMode = AppConstants.MODE_INSERT
            assignAddress("")
            val currentDate = Date()
            if (todayDateFormat == null) {
                todayDateFormat = SimpleDateFormat(resources.getString(R.string.today_date_format))
            }
            currentDateString = todayDateFormat!!.format(currentDate)
            assignDateString(currentDateString)
            contentsInput!!.setText("")
            pictureImageView!!.setImageResource(R.drawable.noimagefound)
        }
    }

    fun assignAddress(data: String?) {
        locationTextView!!.text = data
    }

    fun assignDateString(dateString: String?) {
        dateTextView!!.text = dateString
    }

    fun assignContents(data: String?) {
        contentsInput!!.setText(data)
    }

    fun assignPicture(picturePath: String?, sampleSize: Int) {
        val options = BitmapFactory.Options()
        options.inSampleSize = sampleSize
        resultPhotoBitmap = BitmapFactory.decodeFile(picturePath, options)
        pictureImageView!!.setImageBitmap(resultPhotoBitmap)
    }
}

//        pictureImageView?.setOnClickListener(View.OnClickListener {
//            if (isPhotoCaptured || isPhotoFileSaved) {
//                showDialog(AppConstants.CONTENT_PHOTO_EX)
//            }
//            else {
//                showDialog(AppConstants.CONTENT_PHOTO)
//            }
//        })


//    fun showDialog(id: Int) {
//        var builder: AlertDialog.Builder? = null
//        when(id) {
//            AppConstants.CONTENT_PHOTO -> {
//                builder = AlertDialog.Builder(requireContext())
//                builder.setTitle("사진 메뉴 선택")
//                builder.setSingleChoiceItems(R.array.array_photo, 0,
//                    DialogInterface.OnClickListener { dialog, whichButton ->
//                    selectedPhotoMenu = whichButton
//                })
//                builder.setPositiveButton("선택",
//                DialogInterface.OnClickListener { dialog, whichButton ->
//                    if (selectedPhotoMenu == 0) {
//                        showPhotoCaptureActivity()
//                    } else if (selectedPhotoMenu == 1) {
//                        showPhotoSelectionActivity()
//                    }
//                })
//                builder.setNegativeButton("취소",
//                DialogInterface.OnClickListener { dialog, whichButton -> })
//            }
//            AppConstants.CONTENT_PHOTO_EX -> {
//                builder = AlertDialog.Builder(requireContext())
//                builder.setTitle("사진 메뉴 선택")
//                builder.setSingleChoiceItems(R.array.array_photo_ex, 0,
//                    DialogInterface.OnClickListener { dialog, whichButton ->
//                    if (selectedPhotoMenu == 0) {
//                        showPhotoCaptureActivity()
//                    } else if (selectedPhotoMenu == 1) {
//                        showPhotoSelectionActivity()
//                    } else if (selectedPhotoMenu == 2) {
//                        isPhotoCanceled = true
//                        isPhotoCaptured = false
//                        pictureImageView!!.setImageResource(R.drawable.picture1)
//                    }
//                })
//                builder.setNegativeButton("취소",
//                    DialogInterface.OnClickListener { dialog, whichButton -> })
//            }
//            else -> {
//
//            }
//        }
//        val dialog = builder!!.create()
//        dialog.show()
//    }

//    fun showPhotoCaptureActivity() {
//        try {
//            file = createFile()
//            if (file!!.exists()) {
//                file!!.delete()
//            }
//            file!!.createNewFile()
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//        uri = if (Build.VERSION.SDK_INT >= 24) {
//            FileProvider.getUriForFile(requireContext(), BuildConfig.APPLICATION_ID, file!!)
//        } else {
//            Uri.fromFile(file)
//        }
//        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
//        startActivityForResult(intent, AppConstants.REQ_PHOTO_CAPTURE)
//    }

//    private fun createFile(): File {
//        val filename = createFilename()
//        val outFile = File(requireContext().filesDir, filename)
//
//        return outFile
//    }
//
//    private fun createFilename(): String {
//        val curDate = Date()
//        return curDate.time.toString()
//    }
//
//    fun showPhotoSelectionActivity() {
//        val intent = Intent()
//        intent.type = "image/*"
//        intent.action = Intent.ACTION_GET_CONTENT
//        startActivityForResult(intent, AppConstants.REQ_PHOTO_SELECTION)
//    }
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, intent: Intent?) {
//        super.onActivityResult(requestCode, resultCode, intent)
//        if (intent != null) {
//            when (requestCode) {
//                AppConstants.REQ_PHOTO_CAPTURE -> {
//                    resultPhotoBitmap = decodeSampledBitmapFromResource(
//                        file,
//                        pictureImageView!!.width,
//                        pictureImageView!!.height
//                    )
//                    pictureImageView!!.setImageBitmap(resultPhotoBitmap)
//                }
//                AppConstants.REQ_PHOTO_SELECTION -> {
//                    val fileUri = intent.data
//                    val resolver = requireContext().contentResolver
//
//                    try {
//                        val instream = resolver.openInputStream(fileUri!!)
//                        resultPhotoBitmap = BitmapFactory.decodeStream(instream)
//                        pictureImageView!!.setImageBitmap(resultPhotoBitmap)
//                        instream!!.close()
//                        isPhotoCaptured = true
////                        AppConstants.println("fileUri")
//                        AppConstants.println("fileUri ${fileUri!!}")
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//                }
//            }
//        }
//    }


//    fun decodeSampledBitmapFromResource(res: File?, reqWidth: Int, reqHeight: Int) : Bitmap {
//    val options = BitmapFactory.Options()
//        options.inJustDecodeBounds = true
//        BitmapFactory.decodeFile(res!!.absolutePath, options)
//
//        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
//
//        options.inJustDecodeBounds = false
//        return BitmapFactory.decodeFile(res.absolutePath, options)
//    }
//
//    fun calculateInSampleSize(
//        options: BitmapFactory.Options,
//        reqWidth: Int,
//        reqHeight: Int
//    ): Int {
//        val height = options.outHeight
//        val width = options.outWidth
//        var inSampleSize = 1
//        if (height > reqHeight || width > reqWidth) {
//            while (height / inSampleSize >= reqHeight
//                && width / inSampleSize >= reqWidth
//            ) {
//                inSampleSize *= 2
//            }
//        }
//        return inSampleSize
//    }
//
//    fun applyItem() {
//        if (item != null) {
//            mMode = AppConstants.MODE_MODIFY
//            assignAddress(item!!.address)
//            assignDateString(item!!.createDateStr)
//            assignContents(item!!.contents)
//            val picturePath: String = item!!.picture
//            if (picturePath == null || picturePath == "") {
//                pictureImageView!!.setImageResource(R.drawable.noimagefound)
//            } else {
//                assignPicture(item!!.picture, 1)
//            }
//        } else {
//            mMode = AppConstants.MODE_INSERT
//            assignAddress("")
//            val currentDate = Date()
//            if (todayDateFormat == null) {
//                todayDateFormat = SimpleDateFormat(resources.getString(R.string.today_date_format))
//            }
//            currentDateString = todayDateFormat!!.format(currentDate)
//            assignDateString(currentDateString)
//            contentsInput!!.setText("")
//            pictureImageView!!.setImageResource(R.drawable.noimagefound)
//        }
//    }
//
//    fun assignAddress(data: String?) {
//        locationTextView!!.text = data
//    }
//
//    fun assignDateString(dateString: String?) {
//        dateTextView!!.text = dateString
//    }
//
//    fun assignContents(data: String?) {
//        contentsInput!!.setText(data)
//    }
//
//    fun assignPicture(picturePath: String?, sampleSize: Int) {
//        val options = BitmapFactory.Options()
//        options.inSampleSize = sampleSize
//        resultPhotoBitmap = BitmapFactory.decodeFile(picturePath, options)
//        pictureImageView!!.setImageBitmap(resultPhotoBitmap)
//    }
//
//    fun assignItem(item: Note?) {
//        this.item = item
//    }

