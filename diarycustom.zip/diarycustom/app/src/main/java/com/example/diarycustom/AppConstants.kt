package com.example.diarycustom

public class AppConstants {
    companion object {
        val MODE_INSERT = 1
        val MODE_MODIFY = 2
    }
}